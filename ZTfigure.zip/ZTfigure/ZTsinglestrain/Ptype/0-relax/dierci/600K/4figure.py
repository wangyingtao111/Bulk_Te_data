import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

# === 1. 顶刊级全局排版参数设置 (NPG Style) ===
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica']
plt.rcParams['mathtext.fontset'] = 'custom'
plt.rcParams['mathtext.rm'] = 'Arial'
plt.rcParams['mathtext.it'] = 'Arial:italic'

plt.rcParams.update({
    'font.size': 20,
    'axes.linewidth': 2.0,
    'xtick.major.width': 2.0,
    'xtick.major.size': 6,
    'ytick.major.width': 2.0,
    'ytick.major.size': 6,
    'xtick.minor.width': 1.5,
    'xtick.minor.size': 4,
    'ytick.minor.width': 1.5,
    'ytick.minor.size': 4,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'lines.linewidth': 4
})

# === 2. 加载与数据准备 ===
df = pd.read_csv("amset_columns.csv")
doping = np.abs(df["doping"])

# === 3. 创建画布 (4x1 子图结构，竖版) ===
fig, axs = plt.subplots(4, 1, figsize=(6, 16))  # 修改为4行1列，调整宽度和高度
fig.subplots_adjust(hspace=0.25, bottom=0.08, top=0.95)  # 调整底部和顶部边距

# 定义样式 (NPG 配色)
styles = {'xx': ('#43A3EFCC', '-'), 
          'yy': ('#EF767BCC', '-'), 
          'zz': ('#293890CC', '-')}

# --- 新增：定义图例标签映射字典 ---
direction_labels = {
    'xx': '$a$-axis',
    'yy': '$b$-axis',
    'zz': '$c$-axis'
}

# --- 循环绘制前三个属性 ---
properties = [
   ('sigma', r'$\boldsymbol{\sigma}$ ($\mathbf{S \cdot m^{-1}}$)'),
    ('S', r'$\mathbf{S}$ ($\boldsymbol{\mu}\mathbf{V \cdot K^{-1}}$)'),
    ('kappa_e', r'$\boldsymbol{\kappa}_{\mathbf{e}}$ ($\mathbf{W \cdot m^{-1} \cdot K^{-1}}$)')
]

# i 会依次等于 0, 1, 2，分别对应前三个子图
for i, (prop, ylabel) in enumerate(properties):
    for dir_ in ['xx', 'yy', 'zz']:
        col = f'{prop}_{dir_}'
        color, ls = styles[dir_]
        # 修改 label 参数，使用映射字典
        axs[i].plot(doping, df[col], color=color, linestyle=ls, label=direction_labels[dir_])
    
    axs[i].set_ylabel(ylabel, fontweight='bold')

# --- 图 4 (axs[3]): 功率因子 (Power Factor, PF) ---
for dir_ in ['xx', 'yy', 'zz']:
    S_col = f'S_{dir_}'
    sigma_col = f'sigma_{dir_}'
    # PF = S^2 * sigma，转换为 10^-3 W/(m K^2) 量级
    pf_values = (df[S_col] * 1e-6)**2 * df[sigma_col] * 1e3
    
    color, ls = styles[dir_]
    # 修改 label 参数，使用映射字典
    axs[3].plot(doping, pf_values, color=color, linestyle=ls, label=direction_labels[dir_])

# PF 的 Y 轴标签
axs[3].set_ylabel(r'$\mathbf{PF}$ ($\mathbf{10^{-3} \cdot W \cdot m^{-1} \cdot K^{-2}}$)', fontweight='bold')

# === 4. 统一格式设置 ===
for i, ax in enumerate(axs):  # 遍历 4 个子图
    ax.set_xscale('log')
    # 设置 X 轴从 10^17 开始
    ax.set_xlim(1e17, 1e21) 
    
    # X 轴标签统一修复正体单位（只给最后一个子图设置xlabel）
    if i == 3:  # 只有最后一个子图显示x轴标签
        ax.set_xlabel(r'Carrier concentration, $\mathbf{n}$ ($\mathbf{cm^{-3}}$)', fontweight='bold')
    
    # 副刻度线设置
    locmin = ticker.LogLocator(base=10.0, subs=(0.2, 0.4, 0.6, 0.8), numticks=12)
    ax.xaxis.set_minor_locator(locmin)
    ax.xaxis.set_minor_formatter(ticker.NullFormatter())
    
    # 网格与图例
    ax.grid(True, which='major', linestyle='--', linewidth=1.0, color='gray', alpha=0.15)
    
    # 因为每个图的标签都一样，你可以选择只给第一个图加图例，或者每个图都加
    # 这里保持原逻辑，给每个图都加上图例
    ax.legend(frameon=False, loc='best', fontsize=20)

# === 5. 输出图片 ===
plt.savefig("TE_properties_all_NPG_vertical.pdf", dpi=600, bbox_inches='tight')
plt.savefig("TE_properties_all_NPG_vertical.png", dpi=600, bbox_inches='tight')

print("✅ 包含 4 个子图的 NPG 顶级期刊风格图表绘制完成（已更新晶体学方向图例）。")
plt.show()
