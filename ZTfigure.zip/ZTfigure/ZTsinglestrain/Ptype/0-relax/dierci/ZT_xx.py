import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib import cm

# === 1. 顶刊级全局排版参数设置 (NPG Style & 中文支持) ===
plt.rcParams['font.family'] = 'sans-serif'
# 设置常见中文字体，确保在不同操作系统下都能正确渲染中文图注
plt.rcParams['font.sans-serif'] = ['SimHei', 'PingFang SC', 'Microsoft YaHei', 'Arial']
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示为方块的问题
plt.rcParams['mathtext.fontset'] = 'custom'
plt.rcParams['mathtext.rm'] = 'Arial'
plt.rcParams['mathtext.it'] = 'Arial:italic'

plt.rcParams.update({
    'font.size': 16,          
    'axes.linewidth': 2.0,    
    'xtick.major.width': 2.0, 
    'xtick.major.size': 6,    
    'ytick.major.width': 2.0, 
    'ytick.major.size': 6,    
    'xtick.minor.width': 1.5, 
    'xtick.minor.size': 4,
    'ytick.minor.width': 1.5,
    'ytick.minor.size': 4,
    'xtick.direction': 'in',  
    'ytick.direction': 'in',
    'lines.linewidth': 2.5    
})

# === 2. 加载数据与物理常数设定 ===
# 根据 Excel 提取 300K-1000K 的 xx 方向晶格热导率 (W m^-1 K^-1)
kappa_l_xx = {
    300: 1.31,
    400: 0.98,
    500: 0.79,
    600: 0.66,
    700: 0.57,
    800: 0.5,
    900: 0.44,
    1000: 0.4
}

temperatures = [300, 400, 500, 600, 700, 800, 900, 1000]

# === 3. 创建画布 ===
fig, ax = plt.subplots(figsize=(7.5, 6)) 

# 使用冷暖色带映射温度变化 (蓝色表示低温，红色表示高温)
colors = cm.coolwarm(np.linspace(0, 1, len(temperatures)))

# --- 循环读取不同温度文件夹的数据并计算 xx 方向的 ZT ---
for i, T in enumerate(temperatures):
    # 构建相对路径，例如 "300K/amset_columns.csv"
    file_path = os.path.join(f"{T}K", "amset_columns.csv")
    
    if not os.path.exists(file_path):
        print(f"⚠️ 警告：找不到文件 {file_path}，已跳过 {T}K。")
        continue

    df = pd.read_csv(file_path)
    doping = np.abs(df["doping"])

    # 读取 xx 方向对应的电学参量
    S_uV_K = df['S_xx']         # uV/K
    sigma = df['sigma_xx']      # S/m
    kappa_e = df['kappa_e_xx']  # W/(m K)
    
    # 核心物理计算: ZT = (S^2 * sigma * T) / (kappa_e + kappa_l)
    S_V_K = S_uV_K * 1e-6
    ZT = (S_V_K**2 * sigma * T) / (kappa_e + kappa_l_xx[T])
    
    # 绘制曲线
    ax.plot(doping, ZT, color=colors[i], label=f'{T} K')

# === 4. 坐标轴与排版精调 ===
ax.set_xscale('log')

# 中文标签
ax.set_ylabel('Figure of merit, ZT', fontweight='bold')
ax.set_xlabel('Carrier concentration, n $\mathbf{(cm^{-3})}$', fontweight='bold')
plt.xlim(1e18, 1e21)
# 强制开启 X 轴的副刻度线
locmin = ticker.LogLocator(base=10.0, subs=(0.2, 0.4, 0.6, 0.8), numticks=12)
ax.xaxis.set_minor_locator(locmin)
ax.xaxis.set_minor_formatter(ticker.NullFormatter())

# 图例设置：使用双列排版以节省作图空间
ax.legend(frameon=False, loc='upper right', handlelength=2.5, fontsize=14, ncol=1)
ax.grid(True, which='major', linestyle='--', linewidth=1.0, color='gray', alpha=0.15)

# === 5. 输出高精度图片 ===
plt.tight_layout()
plt.savefig("ZT_xx_300_1000K_NPG_Style.pdf", dpi=600, bbox_inches='tight')
plt.savefig("ZT_xx_300_1000K_NPG_Style.png", dpi=600, bbox_inches='tight')

print("✅ xx方向多温度热电优值 (ZT) 曲线绘制完成！已保存为 PDF 和 PNG 格式。")
plt.show()
