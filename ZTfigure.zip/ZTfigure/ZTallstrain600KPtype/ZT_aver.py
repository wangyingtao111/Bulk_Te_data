import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

# === 1. 顶刊级全局排版参数设置 (NPG Style, 纯英文) ===
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = True 
plt.rcParams['mathtext.fontset'] = 'custom'
plt.rcParams['mathtext.rm'] = 'Arial'
plt.rcParams['mathtext.it'] = 'Arial:italic'

plt.rcParams.update({
    'font.size': 16,          
    'axes.linewidth': 2.0,    
    'xtick.major.width': 2.0, 
    'xtick.major.size': 6,    
    'ytick.major.width': 2.0, 
    'ytick.major.size': 6,    
    'xtick.minor.width': 1.5, 
    'xtick.minor.size': 4,
    'ytick.minor.width': 1.5,
    'ytick.minor.size': 4,
    'xtick.direction': 'in',  
    'ytick.direction': 'in',
    'lines.linewidth': 2.5    
})

# === 2. 加载数据与物理常数设定 ===
T = 600 # 统一温度为 400K

# 提取 400K 下各应变状态三个方向平均的晶格热导率 (即 (kx + ky + kz) / 3)
strain_folders = ['0-relax', '1%Tensile', '2%Tensile', '5-yasuo1%', '6-yasuo2%']

# 【关键修改点 1】：请在这里填入三个方向平均后的晶格热导率真实数据
kappa_l_ave = {
    '0-relax': 1.03,   # 替换为平均值
    '1%Tensile': 0.8667,    # 替换为平均值
    '2%Tensile': 0.9133,     # 替换为平均值
    '5-yasuo1%': 1.03, # 替换为平均值
    '6-yasuo2%': 0.9267   # 替换为替换值
}

# 纯英文图例标签显示
legend_labels = {
    '0-relax': 'Relaxed',
    '1%Tensile': '1% Tensile',
    '2%Tensile': '2% Tensile',
    '5-yasuo1%': '1% Comp.',
    '6-yasuo2%': '2% Comp.'
}

# === 3. 创建画布 ===
fig, ax = plt.subplots(figsize=(7.5, 6)) 

# Nature 级别的高级配色列表
nature_colors = [
    '#828FCE', '#FBBE4F', '#FC6058', '#BEDC9C', '#63A9C9'
]

print("=== Optimal Average ZT Values at 600K under Various Strains ===")

# --- 循环读取不同应变文件夹的数据并计算平均 ZT ---
for i, folder in enumerate(strain_folders):
    file_path = os.path.join(folder, "amset_columns.csv")
    
    if not os.path.exists(file_path):
        print(f"⚠️ Warning: File {file_path} not found, skipping {folder}.")
        continue 

    # 读取数据
    df = pd.read_csv(file_path)
    doping = np.abs(df["doping"])

    # 【关键修改点 2】：同时读取 x, y, z 三个方向的电学参量并计算算术平均值
    S_uV_K = (df['S_xx'] + df['S_yy'] + df['S_zz']) / 3               # uV/K
    sigma = (df['sigma_xx'] + df['sigma_yy'] + df['sigma_zz']) / 3    # S/m
    kappa_e = (df['kappa_e_xx'] + df['kappa_e_yy'] + df['kappa_e_zz']) / 3  # W/(m K)
    
    # 注：在多晶或各向同性近似中，更严谨的平均塞贝克系数计算通常采用电导率加权法：
    # S_uV_K = (df['S_xx']*df['sigma_xx'] + df['S_yy']*df['sigma_yy'] + df['S_zz']*df['sigma_zz']) / (df['sigma_xx'] + df['sigma_yy'] + df['sigma_zz'])
    
    # 核心物理计算: ZT
    S_V_K = S_uV_K * 1e-6
    # 使用平均电子热导率和平均晶格热导率
    ZT = (S_V_K**2 * sigma * T) / (kappa_e + kappa_l_ave[folder])
    
    # === 视觉层级设定：突出特定应变状态 ===
    if folder == '2%Tensile': 
        line_w = 4.0          
        line_alpha = 1.0      
        line_z = 4            
        marker_size = 150     
    else:
        line_w = 2.0          
        line_alpha = 1.0     
        line_z = 3            
        marker_size = 100     

    # === 限制浓度范围并寻找极值 ===
    valid_mask = doping >= 1e18
    if valid_mask.any(): 
        max_idx = ZT[valid_mask].idxmax()            
        max_ZT = ZT.loc[max_idx]         
        opt_doping = doping.loc[max_idx]
        
        print(f"[{legend_labels[folder]:<16}]: Max ZT = {max_ZT:.4f}, Optimal Doping = {opt_doping:.2e} cm^-3")
        
        # 绘制极值标记
        ax.scatter(opt_doping, max_ZT, color=nature_colors[i], marker='D', 
                   s=marker_size, zorder=5, edgecolors='white', linewidths=1.5)
        
    # 绘制完整曲线
    ax.plot(doping, ZT, color=nature_colors[i], label=legend_labels[folder],
            linewidth=line_w, alpha=line_alpha, zorder=line_z)

# === 4. 坐标轴与排版精调 ===
ax.set_xscale('log')

ax.set_ylabel('Figure of merit, ZT', fontweight='bold')
ax.set_xlabel('Carrier concentration, n $\mathbf{(cm^{-3})}$', fontweight='bold')

ax.set_xlim(1e18, 2e20)

# 强制开启 X 轴的副刻度线
locmin = ticker.LogLocator(base=10.0, subs=(0.2, 0.4, 0.6, 0.8), numticks=12)
ax.xaxis.set_minor_locator(locmin)
ax.xaxis.set_minor_formatter(ticker.NullFormatter())

ax.legend(frameon=False, loc='best', handlelength=2.5, fontsize=14)
ax.grid(True, which='major', linestyle='--', linewidth=1.0, color='#BDBDBD', alpha=0.3)

# === 5. 输出高精度图片 ===
plt.tight_layout()
# 【关键修改点 3】：修改输出文件名，表意为平均值（ave）避免覆盖原图
plt.savefig("ZT_ave_400K_Strain_NatureStyle.pdf", dpi=600, bbox_inches='tight')
plt.savefig("ZT_ave_400K_Strain_NatureStyle.png", dpi=600, bbox_inches='tight')

print("\n✅ 代码执行成功！平均 ZT 曲线图表已按规范生成。")
plt.show()
